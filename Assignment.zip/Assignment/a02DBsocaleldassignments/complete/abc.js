let datab=
{
    host: 'localhost',
    user: 'GaneshW',
    password: '1234',
    database: 'Wptstudy',
	port:3306
};
const express=require("express");

const app=express();
const mysql=require("mysql2");
const con=mysql.createConnection(datab);
app.use(express.static("cf"));


app.get("/Add",(req,res)=>{
    
    let input={status:false,Empno:req.query.Empno,Ename:req.query.Ename,salary:req.query.salary};
    // console.log(input);
    // console.log("Add statement called");
    con.query("insert into company (Empno,Ename,salary) values(?,?,?)",[input.Empno,input.Ename,input.salary],
    (err,resp)=>{
        if(err){
            console.log("not inserted");
        }else{
            console.log("Successfully inserted");
            input.status=true;
        }
        res.send(input);
    });
    


});
app.get("/Blur",(req,res)=>{
    
    let data={status:false,details:[]};
    let input=req.query.input;
    
    con.query("select * from company where Empno=?",[input],
    (err,rows)=>{
        if(err){
            console.log("Data Not found");
        }else{
            if(rows.length>0){
            console.log("Data found");
            data.status=true;
            data.details=rows;
        }}
        res.send(data);
    });
});
app.get("/Update",(req,res)=>{
    
    console.log("Update clicked");
    let data={status:false,details:[]};
    let input={Empno:req.query.Empno,Ename:req.query.Ename,salary:req.query.salary};
    console.log(input);
    con.query("update company set Ename=?, salary=? where Empno=?",[input.Ename,input.salary,input.Empno],
    (err,resp)=>{
        if(err){
            console.log("Data not updated");
        }else{
            if(resp.affectedRows>0){
            console.log("Data Updated");
            data.status=true;
          }
        }

         res.send(data);
    });
});
app.get("/Delete",(req,res)=>{
    
    console.log("Delete clicked");
    let data={status:false,details:[]};
    let input={Empno:req.query.Empno};
    
    console.log(input);
    con.query("delete from company where empno=?;",[input.Empno],
    (err,resp)=>{
        if(err){
            console.log("Data not Deleted");
        }else{
            if(resp.affectedRows>0){
            console.log("Data Deleted");
            data.status=true;
          }
        }

         res.send(data);
    });
});
app.get("/GetAll",(req,resp)=>{

    con.query('select * from company',[],(error,rows)=>{

        
        resp.send(rows);

}
);
   




});



app.listen(300,function(){
    console.log("server running at port 300")
});