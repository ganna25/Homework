// const { response } = require('express');
const express=require("express");
const app=express();

app.use(express.static("cf"));
app.get("/additem",(req,resp)=>{
    resp.send("Additems");
    
});
app.get("/removeitem",(req,resp)=>{
    resp.send("Removeitems");
});
app.listen(900, function(){
    console.log("server listening at port 900");
});